///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	
	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ,
	glm::vec3 offset)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ + offset);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/
	bool bReturn = false;

	//FOR CHECKER BOARD
	// load the stained wood texture (DESK)
	bReturn = CreateGLTexture("textures/Wood.jpg", "wood_texture");
	// load the CheckerBoard
	bReturn = CreateGLTexture("textures/Checkboard.jpg","CheckBoard");


	// load in table texture
	bReturn = CreateGLTexture("textures/Table.jpg", "table_texture");



	//FOR BOOK
	
	//load in book texture 
	bReturn = CreateGLTexture("textures/Book.jpg", "book");
	//load in pages texture
	bReturn = CreateGLTexture("textures/pages.jpg", "pages");

	//FOR LAMP
	
	//Add Metal texture
	bReturn = CreateGLTexture("textures/metal.jpg", "metal");
	//Add Linen texture
	bReturn = CreateGLTexture("textures/Linen.jpg", "linen");


	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

void SceneManager::SetupSceneLights()
{
	// Enable lighting
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Configure a directional light for general ambient illumination
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// Directional Light (ambient-like)
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.3f, 0.3f, 0.3f); // Neutral ambient light
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.5f, 0.5f, 0.5f); // Softer diffuse light
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.2f, 0.2f, 0.2f); // Subtle specular highlights
	m_pShaderManager->setVec3Value("directionalLight.direction", -0.5f, -1.0f, -0.5f); // Downward direction

	//Configure the Point Light inside the cylinder
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// Warm Point Light
	m_pShaderManager->setVec3Value("pointLights[0].position", 7.5f, 4.25f, 5.0f); // Slightly above cylinder's center
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.6f, 0.5f, 0.3f); // Strong warm ambient light
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 1.0f, 0.8f, 0.6f); // Bright diffuse for glowing effect
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.3f, 0.2f, 0.1f); // Subtle specular highlights


}


void SceneManager::DefineObjectMaterials()
{

	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.diffuseColor = glm::vec3(0.9f, 0.85f, 0.75f); // Slightly softer colors for a ceramic look.
	ceramicMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);  // Reduced specular reflection.
	ceramicMaterial.shininess = 15.0;                             // Lower shininess for a matte finish.
	ceramicMaterial.tag = "ceramic";
	m_objectMaterials.push_back(ceramicMaterial);
	
	OBJECT_MATERIAL glowingMaterial;
	glowingMaterial.diffuseColor = glm::vec3(0.9f, 0.8f, 0.6f); // Warm light color for lamp
	glowingMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f); // Minimal specular reflection
	glowingMaterial.shininess = 4.0f; // Softer highlights
	glowingMaterial.tag = "lampCover";
	m_objectMaterials.push_back(glowingMaterial);
	
	OBJECT_MATERIAL glossyWoodMaterial;
	glossyWoodMaterial.diffuseColor = glm::vec3(0.55f, 0.27f, 0.07f); // Rich, medium brown for wood
	glossyWoodMaterial.specularColor = glm::vec3(0.4f, 0.2f, 0.1f);  // Glossy highlights with a subtle warm tone
	glossyWoodMaterial.shininess = 20.0f; // Moderate shininess for a glossy appearance
	glossyWoodMaterial.tag = "woodCover";
	m_objectMaterials.push_back(glossyWoodMaterial);

	OBJECT_MATERIAL clothMaterial;
	clothMaterial.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f); // Neutral gray tone for fabric
	clothMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f); // Very low specular reflection for a matte finish
	clothMaterial.shininess = 2.0f; // Minimal shininess for a soft, cloth-like appearance
	clothMaterial.tag = "clothCover";
	m_objectMaterials.push_back(clothMaterial);

	OBJECT_MATERIAL steelMaterial;
	steelMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f); // Neutral gray for metallic look
	steelMaterial.specularColor = glm::vec3(0.8f, 0.8f, 0.8f); // High specular reflection for shiny steel
	steelMaterial.shininess = 50.0f; // High shininess for a polished metal appearance
	steelMaterial.tag = "steel";
	m_objectMaterials.push_back(steelMaterial);

	// Create a material for the CheckBoard texture
	OBJECT_MATERIAL checkBoardMaterial;
	checkBoardMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f); // White diffuse base for a checkerboard
	checkBoardMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f); // Low specular reflection for a flat look
	checkBoardMaterial.shininess = 10.0f; // Low shininess
	checkBoardMaterial.tag = "CheckBoardMaterial";
	m_objectMaterials.push_back(checkBoardMaterial);

	// Create a material for the wood texture
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.4f, 0.25f, 0.15f); // Muted brown for aged wood
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f); // Very low specular reflection
	woodMaterial.shininess = 5.0f; // Very rough
	woodMaterial.tag = "woodCheck";
	m_objectMaterials.push_back(woodMaterial);

}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{

	//Configure Materials
	DefineObjectMaterials();

	//Sets up the lighting for the scene
	SetupSceneLights();

	//load the scene texture
	LoadSceneTextures();


	m_basicMeshes->LoadPlaneMesh();
	//Load Cylinder
	m_basicMeshes->LoadCylinderMesh();
	// Load Torus
	m_basicMeshes->LoadTorusMesh();
	// Load Box
	m_basicMeshes->LoadBoxMesh();

}



/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(10.5f, 1.0f, 6.25f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1, 1, 1, 1);

	// draw the mesh with transformation values
	SetShaderTexture("table_texture");

	// Apply the wood cover material to simulate a polished wooden surface.
	SetShaderMaterial("woodCover");

	//Draw a plane to represent a Desk
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/


	/****************************************************************/
	/*** Define Parent Transformations for Cylinder & Torus ***/
	/****************************************************************/
	// Neutral parent transformations (start as identity/no effect)
	glm::vec3 parentScale = glm::vec3(1.0f, 1.0f, 1.0f);         // Neutral scale
	glm::vec3 parentRotation = glm::vec3(0.0f, 0.0f, 0.0f);      // Neutral rotation
	glm::vec3 parentPosition = glm::vec3(0.0f, 0.0f, 0.0f);      // Neutral position

	// ParentScale, parentRotation, and parentPosition dynamically as needed
	parentScale = glm::vec3(1.0f, 1.0f, 1.0f);                   //  Dynamic scale
	parentRotation = glm::vec3(0.0f, -20.0f, 0.0f);              //  Dynamic rotation
	parentPosition = glm::vec3(8.0f, 0.0f, -5.0f);                // Dynamic translation

	/****************************************************************/
	/*** Draw the Cylinder Mesh to be Coffee Mug ***/
	/****************************************************************/

	// Cylinder's original transformations
	glm::vec3 cylinderScale = glm::vec3(1.0f, 2.75f, 1.0f);
	float cylinderXRotation = 0.0f;
	float cylinderYRotation = 0.0f;
	float cylinderZRotation = 0.0f;
	glm::vec3 cylinderPosition = glm::vec3(0.0f, 0.0f, 0.0f);

	// Apply parent transformations
	scaleXYZ = cylinderScale * parentScale;  // Scale combines
	XrotationDegrees = cylinderXRotation + parentRotation.x;
	YrotationDegrees = cylinderYRotation + parentRotation.y;
	ZrotationDegrees = cylinderZRotation + parentRotation.z;
	positionXYZ = cylinderPosition + parentPosition;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	//Determines the color is red
	SetShaderColor(0.78f, 0.31f, 0.28f, 1.0f);
	//Adds ceramic material to coffee cup cylinder
	SetShaderMaterial("ceramic");
	//Draws cylinder
	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/
	/*** Draw the Torus Mesh to be Coffee Cup Handle ***/
	/****************************************************************/

	// Torus's original transformations
	glm::vec3 torusScale = glm::vec3(1.0f, 1.0f, 1.5f);  //  torus scale
	float torusXRotation = 0.0f;
	float torusYRotation = 0.0f;
	float torusZRotation = 0.0f;
	glm::vec3 torusPosition = glm::vec3(0.9f, 1.25f, 0.0f);

	// Apply parent transformations
	scaleXYZ = torusScale * parentScale;  // Scale combines
	XrotationDegrees = torusXRotation + parentRotation.x;
	YrotationDegrees = torusYRotation + parentRotation.y;
	ZrotationDegrees = torusZRotation + parentRotation.z;
	positionXYZ = torusPosition + parentPosition;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//Turns the color red
	SetShaderColor(0.78f, 0.31f, 0.28f, 1.0f);

	//Adds ceramic material to handle
	SetShaderMaterial("ceramic");
	//Draws Torus
	m_basicMeshes->DrawTorusMesh();

	/****************************************************************/
	/*** Draw the Box Mesh ***/
	/****************************************************************/

	// Box's transformations
	glm::vec3 boxScale = glm::vec3(6.0f, 0.5f, 6.0f);  // Box scale
	float boxXRotation = 0.0f;  // No rotation initially
	float boxYRotation = 0.0f;  // No rotation initially
	float boxZRotation = 0.0f;  // No rotation initially
	glm::vec3 boxPosition = glm::vec3(0.0f, 0.26f, 0.0f);  // Box position

	// Set the transformations for the box
	SetTransformations(
		boxScale,
		boxXRotation,
		boxYRotation,
		boxZRotation,
		boxPosition
	);
		

	// Set the shader to use the brick texture
	SetShaderTexture("CheckBoard");

	//A function to set material properties in the shader
	SetShaderMaterial("CheckBoardMaterial"); 

	//Apply checkerboard to the top side of the box
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::BoxSide::top);

	//A function to set material properties in the shader
	SetShaderTexture("wood_texture");
	
	//A function to set material properties in the shader
	SetShaderMaterial("woodCheck");

	// Draw the box mesh using basic meshes
	m_basicMeshes->DrawBoxMesh();

	
	/****************************************************************/
	/*** Draw the Bottom Cover of the Book ***/
	/****************************************************************/

	// Box 1 transformations
	glm::vec3 box1Scale = glm::vec3(3.65f, 0.15f, 3.65f);  // Box 1 scale
	float box1XRotation = 0.0f;  // No rotation
	float box1YRotation = 0.0f;  // No rotation
	float box1ZRotation = 0.0f;  // No rotation
	glm::vec3 box1Position = glm::vec3(-8.0f, 0.15f, -4.5f);  // Position for Box 1

	// Set the transformations for Box 1
	SetTransformations(
		box1Scale,
		box1XRotation,
		box1YRotation,
		box1ZRotation,
		box1Position);

	// Set the shader to use the wood texture for Box 1
	SetShaderTexture("book");

	SetShaderMaterial("clothCover");

	// Draw the Box 1 mesh using basic meshes
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
	/*** Draw the Top Cover of the Book ***/
	/****************************************************************/

	// Box 2 transformations
	glm::vec3 box2Scale = glm::vec3(3.65f, 0.15f, 3.65f);  // Box 2 scale
	float box2XRotation = 0.0f;  // No rotation
	float box2YRotation = 0.0f;  // No rotation
	float box2ZRotation = 0.0f;  // No rotation
	glm::vec3 box2Position = glm::vec3(-8.0f, 0.85f, -4.5);  // Position for Box 2

	// Set the transformations for Box 2
	SetTransformations(
		box2Scale,
		box2XRotation,
		box2YRotation,
		box2ZRotation,
		box2Position);

	// Apply the book texture to Box 2
	SetShaderTexture("book");
	
	// Use the cloth cover material to emulate a hardcover book.
	SetShaderMaterial("clothCover");

	// Draw the Box 2 mesh using basic meshes
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
	/*** Draw the Pages ***/
	/****************************************************************/

	// Box 3 transformations
	glm::vec3 box3Scale = glm::vec3(3.5f, 0.75f, 3.0f);  // Box 3 scale
	float box3XRotation = 0.0f;  // No rotation
	float box3YRotation = 0.0f;  // No rotation
	float box3ZRotation = 0.0f;  // No rotation
	glm::vec3 box3Position = glm::vec3(-8.1f, 0.5f, -4.25f); // Position for Box 3

	// Set the transformations for Box 3
	SetTransformations(
		box3Scale,
		box3XRotation,
		box3YRotation,
		box3ZRotation,
		box3Position);

	// Set the shader to use the pages texture for Box 3
	SetShaderTexture("pages");

	// Draw the Box 3 mesh using basic meshes
	m_basicMeshes->DrawBoxMesh();
	
	/****************************************************************/
	/*** Draw the Book Binding ***/
	/****************************************************************/

	// Plane transformations
	glm::vec3 plane2Scale = glm::vec3(1.78f, 0.1f, 0.45f);  // Plane scale to make it large and flat
	float plane2XRotation = 90.0f;  // Rotated on the 90 degrees
	float plane2YRotation = 90.0f;  // Rotated 90 degrees
	float plane2ZRotation = 0.0f;  // No rotation on Z-axis
	glm::vec3 plane2Position = glm::vec3(-9.86f, 0.5f, -4.5f);  // Position the plane below the boxes

	// Set the transformations for the plane
	SetTransformations(
		plane2Scale,
		plane2XRotation,
		plane2YRotation,
		plane2ZRotation,
		plane2Position);

	// Set the shader to use the book texture to create binding
	SetShaderTexture("book");

	//Add clothCover Material
	SetShaderMaterial("clothCover");

	// Draw the plane mesh using basic meshes
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/
	/*** Base Cylinder for Lamp ***/
	/****************************************************************/

	// Cylinder 1 transformations
	glm::vec3 cylinder1Scale = glm::vec3(1.2f, 0.2f, 1.0f);  // Base cylinder
	float cylinder1XRotation = 0.0f;  // No rotation
	float cylinder1YRotation = 0.0f;  // No rotation
	float cylinder1ZRotation = 0.0f;  // No rotation
	glm::vec3 cylinder1Position = glm::vec3(7.5f, 0.0f, 5.0f);  // Position for Cylinder 1

	// Set the transformations for Cylinder 1
	SetTransformations(
		cylinder1Scale,
		cylinder1XRotation,
		cylinder1YRotation,
		cylinder1ZRotation,
		cylinder1Position);

	// Set the shader to use a material for Cylinder 1
	SetShaderTexture("metal");

	//Add Steel Material
	SetShaderMaterial("steel");

	// Draw Cylinder 1
	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/
	/*** Neck Cylinders for Lamp ***/
	/****************************************************************/

	glm::vec3 cylinder2Scale = glm::vec3(0.2f, 4.0f, 0.2f);  // Neck of cylinder
	float cylinder2XRotation = 0.0f;  // No rotation
	float cylinder2YRotation = 30.0f;  // Rotated on Y-axis
	float cylinder2ZRotation = 0.0f;  // No rotation
	glm::vec3 cylinder2Position = glm::vec3(7.5f, 0.0f, 5.0f);  // Position for Cylinder 2

	// Set the transformations for Cylinder 2
	SetTransformations(
		cylinder2Scale,
		cylinder2XRotation,
		cylinder2YRotation,
		cylinder2ZRotation,
		cylinder2Position);

	// Set the shader to use a material for Cylinder 
	SetShaderTexture("metal");
	
	//Add Steel Material for neck of lamp
	SetShaderMaterial("steel");

	// Draw Cylinder 2
	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/
	/***   Cylinder for lamp Shade ***/
	/****************************************************************/

	glm::vec3 cylinder3Scale = glm::vec3(1.5f, 2.0f, 1.5f);  // Wider cylinder
	float cylinder3XRotation = 0.0f;  // No rotation
	float cylinder3YRotation = -30.0f;  // Rotated on Y-axis
	float cylinder3ZRotation = 0.0f;  // No rotation
	glm::vec3 cylinder3Position = glm::vec3(7.5f, 3.75f, 5.0f);  // Position for Cylinder 3

	// Set the transformations for Cylinder 3
	SetTransformations(
		cylinder3Scale,
		cylinder3XRotation,
		cylinder3YRotation,
		cylinder3ZRotation,
		cylinder3Position);

	// Set the shader to use a material for Cylinder 3
	SetShaderTexture("linen");

	// Apply the lamp cover material to simulate the appearance of the lampshade.
	SetShaderMaterial("lampCover");


	// Draw Cylinder 3 
	m_basicMeshes->DrawCylinderMesh();

}